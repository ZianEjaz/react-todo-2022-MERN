import React from "react";

// components import
import TodoComponent from "../components/TodoComponent";

const Home = () => {
  return (
    <div>
      <TodoComponent />
    </div>
  );
};

export default Home;
